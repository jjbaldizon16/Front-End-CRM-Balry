
			<div class="clearfix"></div>
		</div> <!-- fin contenedor -->

		<!-- PIE DE PÁGINA -->
		<footer id="pie">
			<p>Desarrollado por <a href="https://thewebarquitect.com/">The Web Arquictect</a> &copy; 2018</p>
		</footer>
		
	</body>
</html>
