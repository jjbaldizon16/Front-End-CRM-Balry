<?php require_once 'conexion.php'; ?>
<?php require_once 'includes/helpers.php'; ?>
<!DOCTYPE HTML>
<html lang="es">  
	<head>
		<meta charset="utf-8" />
		<title>Blog de Videojuegos</title>
		<link rel="stylesheet" type="text/css" href="./assets/css/style.css" />
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	</head>
	<body>
		<!-- CABECERA -->
		<header id="cabecera">
			<br>
		<div class="pcr-contenedor">
          
		  <h1 class="pcr-title">Sistema Gestion de Clientes <img src="assets/img/logo.png" style="width: 100px;
												 height: 100px;" alt=""> </h1>
		  
			
		  </div>
			
			<!-- MENU -->
			<nav id="menu">
				<ul>
					<li>
						<a href="index.php">Inicio</a>
					</li>
				
								
	                 		<!-- LOGO -->
		
					
					
				</ul>
			
			</nav>
			
			<div class="clearfix"></div>
		</header>
		
		<div id="contenedor">

		