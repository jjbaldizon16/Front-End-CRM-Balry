-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-12-2021 a las 10:42:11
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `gestion_clientes_pcr`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(255) NOT NULL,
  `cedula` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellido1` text COLLATE utf8_spanish_ci NOT NULL,
  `apellido2` text COLLATE utf8_spanish_ci NOT NULL,
  `email` text COLLATE utf8_spanish_ci NOT NULL,
  `telefono1` int(11) NOT NULL,
  `telefono2` int(11) NOT NULL,
  `direccion_casa` longtext COLLATE utf8_spanish_ci NOT NULL,
  `direccion_trabajo` longtext COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `cedula`, `nombre`, `apellido1`, `apellido2`, `email`, `telefono1`, `telefono2`, `direccion_casa`, `direccion_trabajo`) VALUES
(1, 0, 'deportes', '', '0', '0', 0, 0, '', ''),
(2, 903670541, 'Josue1247 ', 'Maldini1247', 'Zanetti', 'correo@hotmail.com', 2147483647, 475893189, '  Londres Inglaterra \r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book', ' Londres Inglaterra \r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book'),
(3, 10245789, 'Alan', 'Aleman', 'Portillo', 'aleman@portillo.com', 20204519, 40001279, 'Tibas central', 'Tibas Central'),
(4, 902054154, 'Alan', 'Aleman', 'Zuñiga', 'zuniga@aleman.com', 22451247, 20214859, 'Heredia, Municipalidad', 'Heredia Municipalidad'),
(5, 40000999, 'Niky Hount', 'Lauda Hount', 'Lauda Hount', 'niky@hount.com', 5555555, 111199999, '   Belgica y Alemania   ', '   Formula1 en todo el mundo.  ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entradas`
--

CREATE TABLE `entradas` (
  `id` int(255) NOT NULL,
  `categoria_id` int(255) NOT NULL,
  `direccion_instalacion` longtext COLLATE utf8_spanish_ci NOT NULL,
  `historial` longtext COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_ultimo_cambio` date NOT NULL,
  `fecha_proximo_cambio` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `entradas`
--

INSERT INTO `entradas` (`id`, `categoria_id`, `direccion_instalacion`, `historial`, `fecha_ultimo_cambio`, `fecha_proximo_cambio`) VALUES
(3, 2, 'Liberia Costa Rica', 'Liberia Costa Rica', '2022-01-17', '2023-01-17'),
(4, 2, 'San Jose Goicochea', 'Se le instalo un Osmosis Inversa', '2021-12-19', '2022-12-19'),
(5, 3, ' Singapur y La India ', ' Sistema para todos los edificios que tiene en ese pais. dfgdsf', '2025-01-21', '2026-01-21'),
(6, 5, ' Munich Alemania y tambien en Belgica', ' Se le instalo para toda la residencia. y para su Avion Privado ', '2022-12-23', '2023-12-23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(255) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellidos`, `email`, `password`, `fecha`) VALUES
(1, 'Josue', 'Baldizon', 'baldizon.cv16@gmail.com', '$2y$04$ImaJRHjHfqBrw3m5s6Mq9.xpo0qzM0xsyqPa8vfc8/.eUgMWQf8Iu', '2021-12-18');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `entradas`
--
ALTER TABLE `entradas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_entrada_categoria` (`categoria_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `entradas`
--
ALTER TABLE `entradas`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `entradas`
--
ALTER TABLE `entradas`
  ADD CONSTRAINT `fk_entrada_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
