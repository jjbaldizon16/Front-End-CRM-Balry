<?php
$usuario_db = 'root';
$contrasena_db = '';
$pdo_conn = new PDO( 'mysql:host=localhost;dbname=php_articulos', $usuario_db, $contrasena_db );
?>